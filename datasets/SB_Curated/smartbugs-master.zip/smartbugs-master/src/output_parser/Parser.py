class Parser:
    def __init__(self):
        pass

    def parse(self, str):
        pass

    def parseSarif(self, str, file_path_in_repo):
        pass
